<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Szekeres Alex Patrik, Merza Nikolett Éva, Takács Lilla">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Pizza rendelés">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    
    <title>Contact Us</title>
    <link rel = "icon" href ="img/logo.jpg" type = "image/x-icon">
    <style>
        .contact2 {
            font-family: "Montserrat", sans-serif;
            color: black;
            font-weight: 100;
            background-image: url(img/map.jpg);
            background-size: cover;
            background-position: center center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .contact-box {
            background-color: #f8f8f8;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        .contact-box h5 {
            font-weight: 600;
        }

        .contact-box p {
            font-size: 18px;
            margin-bottom: 20px;
        }

        .gmail-icon {
            font-size: 24px;
            margin-left: 5px;
        }
    </style>
     <title>Kapcsolatok</title>
    <link rel="icon" href="img/logo.jpg" type="image/x-icon">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
<?php include 'partials/_dbconnect.php';?>
<?php include 'partials/_nav.php';?>

<div class="contact2">
    <div class="container">
        <div class="row contact-container">
            <div class="col-lg-8 mx-auto">
                <div class="contact-box">
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <h2 class="title">Kapcsolatok</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Telefonszám:</h5>
                            <p>+36 123 456 789</p>
                        </div>
                        <div class="col-md-6">
                            <h5>Cím:</h5>
                            <p>123 Pizzalicious Street, Budapest, Hungary</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h5>E-mail cím:</h5>
                            <p>
                                <a href="mailto:pizza@example.com">
                                   </i> pizza@example.com
                                    <i class="fas fa-envelope gmail-icon" title="Send an email via Gmail" onclick="location.href='mailto:pizza@example.com'"></i>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

  <?php include 'partials/_footer.php';?> 

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         

  </body>
</html>





