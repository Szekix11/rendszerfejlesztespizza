<!doctype html>
<html lang="hu">
<head>
<meta charset="UTF-8" >
<meta name="author" content="Szekeres Alex Patrik">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Házi feladat 1">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
        .contact2 {
            font-family: "Montserrat", sans-serif;
            color: #8d97ad;
            font-weight: 300;
            background-image: url(img/map.jpg);
            background-size: cover;
            background-position: center center;
            height: 100vh;
        }

        .contact-box {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .contact-box h4.title {
            color: #3e4555;
        }

        .contact-box .contact-info {
            background-color: rgba(255, 255, 255, 0.7);
            padding: 15px;
            border-radius: 10px;
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .contact-box .contact-info h5 {
            color: #3e4555;
        }

        .contact-box .contact-info .email-icon {
            font-size: 24px;
            margin-right: 10px;
        }
    </style>
    <title>Kapcsolat</title>
    <link rel="icon" href="img/logo.jpg" type="image/x-icon">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">   
  
</head>
<body>
<?php include 'partials/_dbconnect.php';?>
<?php include 'partials/_nav.php';?>

<div class="contact2">
    <div class="container">
        <div class="row contact-container">
            <div class="col-lg-8">
                <div class="contact-box p-4">
                    <div class="row">
                        <div class="col-lg-12">
                            <center><h4 class="title">Kapcsolat</h4></center>
                            <?php
                $sql = "SELECT * FROM `sitedetail`";
                $result = mysqli_query($conn, $sql);
                $row = mysqli_fetch_assoc($result);

                $systemName = $row['systemName'];
                $address = $row['address'];
                $email = $row['email'];
                $contact1 = $row['contact1'];
                $contact2 = $row['contact2'];

                echo '
                    
                    <div class="contact-info"><h5 class="text-white font-weight-light mb-3">Székhely cím</h5>
                    <p class="text-white op-7">' .$address. '</p>
                        <h5 class="font-weight-bold">Elérhetőségek</h5>
                        <p><span class="email-icon"><i class="far fa-envelope"></i></span><a href="mailto:' .$email. '">' .$email. '</a></p>
                        <p>' .$contact1. '<br>' .$contact2. '</p>
      
                </div>';
                ?>
                        </div>
                    </div>
                    <!-- Egyéb űrlap tartalom -->
                </div>
            </div>
            <div class="col-lg-4">
                <!-- Háttérképes tartalom rész -->
             
            </div>
        </div>
    </div>
</div>

<?php include 'partials/_footer.php';?>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</body>
</html>






