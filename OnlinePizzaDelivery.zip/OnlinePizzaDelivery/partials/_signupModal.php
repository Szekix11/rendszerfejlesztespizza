  <!-- Sign up Modal -->
    <div class="modal fade" id="signupModal" tabindex="-1" role="dialog" aria-labelledby="signupModal" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color: rgb(111 202 203);">
            <h5 class="modal-title" id="signupModal">Regisztráció</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="partials/_handleSignup.php" method="post">
              <div class="form-group">
                  <b><label for="username">Felhasználónév</label></b>
                  <input class="form-control" id="username" name="username" placeholder="Válassz felhasználónevet" type="text" required minlength="3" maxlength="11">
              </div>
              <div class="form-row">
                <div class="form-group col-md-6">
                  <b><label for="firstName">Vezetéknév:</label></b>
                  <input type="text" class="form-control" id="firstName" name="firstName"   required>
                </div>
                <div class="form-group col-md-6">
                  <b><label for="lastName">Keresztnév:</label></b>
                  <input type="text" class="form-control" id="lastName" name="lastName"  required>
                </div>
              </div>
              <div class="form-group">
                  <b><label for="email">Email:</label></b>
                  <input type="email" class="form-control" id="email" name="email"  required>
              </div>
              <div class="form-group">
                <b><label for="phone">Phone No:</label></b>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="basic-addon">+36</span>
                  </div>
                  <input type="tel" class="form-control" id="phone" name="phone" required pattern="[0-9]{9}" maxlength="9">
                </div>
              </div>
              <div class="text-left my-2">
                  <b><label for="password">Jelszó:</label></b>
                  <input class="form-control" id="password" name="password"  type="password" required data-toggle="password" minlength="4" maxlength="21">
              </div>
              <div class="text-left my-2">
                  <b><label for="password1">Jelszó megerősítés:</label></b>
                  <input class="form-control" id="cpassword" name="cpassword" type="password" required data-toggle="password" minlength="4" maxlength="21">
              </div>
              <button type="submit" class="btn btn-success">Regisztráció</button>
            </form>
            <p class="mb-0 mt-1">Van már fiókod? <a href="#" data-dismiss="modal" data-toggle="modal" data-target="#loginModal">Jelentkezz be</a>.</p>
          </div>
        </div>
      </div>
    </div>
